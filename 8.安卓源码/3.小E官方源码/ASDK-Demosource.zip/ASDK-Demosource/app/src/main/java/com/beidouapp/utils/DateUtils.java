package com.beidouapp.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {

	/**
	 * 获取当前日期的字符串形式.
	 * 
	 * @return
	 */
	public static String getCurrentDate() {
		// return String.format ("%tF %1$tH:%1$tM:%1$tS.%1$tL",
		// System.currentTimeMillis ());//获取时间，精确到毫秒
		return String.format("%tF %1$tH:%1$tM:%1$tS", System.currentTimeMillis());
	}

	/**
	 * 时间戳转字符串
	 * 
	 * @param cc_time
	 * @return
	 */
	public static String getStrTime(String cc_time) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(new Date(Long.valueOf(cc_time)));
	}
}
