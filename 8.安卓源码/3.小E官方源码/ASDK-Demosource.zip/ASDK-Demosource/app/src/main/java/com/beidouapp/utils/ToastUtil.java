package com.beidouapp.utils;

import android.content.Context;
import android.view.Gravity;
import android.widget.Toast;

public class ToastUtil {

	private static int DURATION = 300;
	private static Toast mToast = null;
	private static boolean CUSTOM = false;// 自定义布局

	public static void showToast(Context ctx, String msg) {
		if (CUSTOM) {
			// showTastCustomContent(ctx, msg, Gravity.CENTER);
		} else {
			showToast(ctx, msg, Gravity.CENTER);
		}
	}

	public static void showToast(Context ctx, String msg, int gravity) {
		if (mToast == null) {
			mToast = Toast.makeText(ctx, msg, DURATION);
			mToast.setDuration(DURATION);
			// mToast.setGravity(gravity, 0, 0);
		}
		mToast.setText(msg);
		mToast.show();
	}

	// private static void showTastCustomContent(Context ctx, String msg, int
	// gravity) {
	// TextView msgView;
	// if (mToast == null) {
	// mToast = Toast.makeText(ctx, msg, DURATION);
	// mToast.setDuration(DURATION);
	// mToast.setGravity(gravity, 0, 0);
	// LayoutInflater inflator = (LayoutInflater) ctx
	// .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	// View view = inflator.inflate(R.layout.toast_view, null);
	// msgView = (TextView) view.findViewById(R.id.toast_message);
	// mToast.setView(view);
	// } else {
	// View view = mToast.getView();
	// msgView = (TextView) view.findViewById(R.id.toast_message);
	// }
	// mToast.setText(msg);
	// msgView.setText(msg);
	// mToast.show();
	//
	// }
}
