package com.beidouapp.utils;

import android.util.Log;

public class TestUtil {
	public static void showTest(String str) {
		Log.i("test", str);
	}
}
