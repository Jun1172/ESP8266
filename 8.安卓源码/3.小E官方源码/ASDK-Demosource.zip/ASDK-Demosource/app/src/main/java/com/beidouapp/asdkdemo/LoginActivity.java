package com.beidouapp.asdkdemo;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.beidouapp.config.EtConstant;
import com.beidouapp.et.client.domain.UserInfo;
import com.beidouapp.utils.ToastUtil;
import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends Activity implements OnClickListener {

    private static List<UserInfo> listUser;
    public ProgressDialog mydialog = null;
    boolean isTest = false;
    Intent intentService;
    private Button btn_login, btn_register, btn_register_commit;
    private EditText et_user_id, et_user_name, et_nick_name, et_app_key,
            et_secret_key, port, serveradd;
    private LinearLayout llay_register = null;
    private CheckBox cb_offline_msg, cb_friend_status, cb_save_offline_msg;
    private MyBroadCaseReceiver rec = null;
    private SharedPreferences sp = null;
    private boolean isExpand = false;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    /**
     * 获取注册用户的信息
     *
     * @return
     */
    public static List<UserInfo> getListUser() {
        return listUser;
    }

    public void setListUser(List<UserInfo> listUser) {
        this.listUser = listUser;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        sp = getSharedPreferences(EtConstant.SHARE_PREFERENCE,
                Context.MODE_PRIVATE);

        IntentFilter filter = new IntentFilter();
        filter.addAction(EtConstant.CONNECT_SUCCESS);
        filter.addAction(EtConstant.CONNECT_FAILURE);
        filter.addAction(EtConstant.REGIST_SUCCESS);
        filter.addAction(EtConstant.REGIST_FAILURE);
        rec = new MyBroadCaseReceiver();
        registerReceiver(rec, filter);
        initView();
        initDate();
        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client = new GoogleApiClient.Builder(this).addApi(AppIndex.API).build();
    }

    public void initDate() {
        if (sp.getBoolean(EtConstant.IS_GET_FRIEND_STATUS, false)) {
            cb_friend_status.setChecked(true);
        } else {
            cb_friend_status.setChecked(false);
        }
        if (sp.getBoolean(EtConstant.IS_SAVE_OFFLINE_MSG, false)) {
            cb_save_offline_msg.setChecked(true);
        } else {
            cb_save_offline_msg.setChecked(false);
        }
        et_app_key.setText(sp.getString(EtConstant.ET_APP_KEY, "9f3ef380-a510-632558"));
        et_secret_key.setText(sp.getString(EtConstant.ET_SECRET_KEY, "db06c78d1e24cf708a14ce81c9b617ec"));
        //  et_user_id.setText(sp.getString(EtConstant.USER_ID, "Fc5wGsTuvumomVom1PA45UZwcMkCmQD4jW"));
        et_user_id.setText(sp.getString(EtConstant.USER_ID, ""));
    }

    public void initView() {
        btn_login = (Button) findViewById(R.id.btn_login);
        btn_login.setOnClickListener(this);
        findViewById(R.id.btn_test).setOnClickListener(this);
        et_user_id = (EditText) findViewById(R.id.et_user_id);
        et_nick_name = (EditText) findViewById(R.id.et_nick_name);
        port = (EditText) findViewById(R.id.et_server_port);
        serveradd = (EditText) findViewById(R.id.et_server_host);
        et_app_key = (EditText) findViewById(R.id.et_app_key);
        et_secret_key = (EditText) findViewById(R.id.et_secret_key);
        llay_register = (LinearLayout) findViewById(R.id.llay_reigister);

        btn_register = (Button) findViewById(R.id.btn_register);
        btn_register.setOnClickListener(this);
        et_user_name = (EditText) findViewById(R.id.et_user_name);

        btn_register_commit = (Button) findViewById(R.id.btn_register_commit);
        btn_register_commit.setOnClickListener(this);

        cb_friend_status = (CheckBox) findViewById(R.id.cb_friend_status);
        cb_friend_status
                .setOnCheckedChangeListener(new OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView,
                                                 boolean isChecked) {
                        sp.edit().putBoolean(EtConstant.IS_GET_FRIEND_STATUS,
                                isChecked).commit();
                    }
                });

        cb_save_offline_msg = (CheckBox) findViewById(R.id.cb_save_offline_msg);
        cb_save_offline_msg
                .setOnCheckedChangeListener(new OnCheckedChangeListener() {

                    @Override
                    public void onCheckedChanged(CompoundButton buttonView,
                                                 boolean isChecked) {
                        sp.edit()
                                .putBoolean(EtConstant.IS_SAVE_OFFLINE_MSG,
                                        isChecked).commit();
                    }
                });
    }

    public void onRegister() {
        if (checkIsNull1()) {
            Toast.makeText(LoginActivity.this, "请补全信息再注册！", Toast.LENGTH_SHORT)
                    .show();
            return;
        }
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean(EtConstant.IS_RIGISTER, true);
        editor.putString(EtConstant.ET_APP_KEY, et_app_key.getText().toString());
        editor.putString(EtConstant.ET_SECRET_KEY, et_secret_key.getText()
                .toString());
        editor.putString(EtConstant.SERVERADD, serveradd.getText().toString()
                .trim());
        editor.putString(EtConstant.PORT, port.getText().toString().trim());
        editor.commit();
        String userName = et_user_name.getText().toString();
        if (userName.length() > 32) {
            Toast.makeText(LoginActivity.this, "userName超长，请重新输入",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        listUser = new ArrayList<UserInfo>();
        // 启动服务 , 初始化sdk
        Intent intentService = new Intent(this.getApplicationContext(),
                IMService.class);
        intentService.putExtra(EtConstant.IS_RIGISTER, true);
        intentService.putExtra(EtConstant.USER_NAME, userName);
        startService(intentService);
    }

    /**
     * 登录
     */
    public void onLogin() {
        if (checkIsNull()) {
            Toast.makeText(LoginActivity.this, "请补全信息再登陆", Toast.LENGTH_SHORT)
                    .show();
            return;
        }
        String userId = et_user_id.getText().toString();
        SharedPreferences.Editor editor = sp.edit();
        editor.putString(EtConstant.USER_ID, userId);
        editor.putBoolean(EtConstant.IS_RIGISTER, false);
        editor.putString(EtConstant.ET_APP_KEY, et_app_key.getText().toString());
        editor.putString(EtConstant.ET_SECRET_KEY, et_secret_key.getText()
                .toString());
        editor.putString(EtConstant.SERVERADD, serveradd.getText().toString()
                .trim());
        editor.putString(EtConstant.PORT, port.getText().toString().trim());
        editor.commit();
        if (userId != null && !userId.equals("")) {
            // 启动服务 , 初始化sdk
            intentService = new Intent(this.getApplicationContext(),
                    IMService.class);
            intentService.putExtra(EtConstant.USER_ID, userId);
            intentService.putExtra(EtConstant.IS_RIGISTER, false);
            startService(intentService);
        } else {
            ToastUtil.showToast(this, "请输入用户名  >_<");
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_login:
                onLogin();
                break;
            case R.id.btn_register:// 显示注册信息
                if (isExpand) {
                    llay_register.setVisibility(View.GONE);
                    isExpand = false;
                } else {
                    llay_register.setVisibility(View.VISIBLE);
                    isExpand = true;
                }
                break;
            case R.id.btn_register_commit:// 确认注册
                // 启动服务 , 初始化sdk
                onRegister();
                break;
            case R.id.btn_test:
                isTest = true;
                onLogin();
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            //  System.exit(0);
            finish();
        }
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (intentService != null) {
            stopService(intentService);
        }
        if (mydialog != null) {
            mydialog.dismiss();
        }
        if (rec != null) {
            unregisterReceiver(rec);
        }
    }

    boolean checkIsNull() {
        String appkey = et_app_key.getText().toString();
        String serverAdd = serveradd.getText().toString().trim();
        String port1 = port.getText().toString().trim();
        String secretkey = et_secret_key.getText().toString();
        String uid = et_user_id.getText().toString();
        if (checkStringIsNull(appkey) || checkStringIsNull(serverAdd)
                || checkStringIsNull(port1) || checkStringIsNull(secretkey)
                || checkStringIsNull(uid)) {// 有为空信息
            return true;
        } else {
            return false;
        }
    }

    boolean checkIsNull1() {
        String appkey = et_app_key.getText().toString();
        String serverAdd = serveradd.getText().toString().trim();
        String port1 = port.getText().toString().trim();
        String secretkey = et_secret_key.getText().toString();
        if (checkStringIsNull(appkey) || checkStringIsNull(serverAdd)
                || checkStringIsNull(port1) || checkStringIsNull(secretkey)) {// 有为空信息
            return true;
        } else {
            return false;
        }
    }

    boolean checkStringIsNull(String str) {
        if (str.equals("") || str == null) {// 为空
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void onStart() {
        super.onStart();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        client.connect();
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Login Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.beidouapp.asdkdemo/http/host/path")
        );
        AppIndex.AppIndexApi.start(client, viewAction);
    }

    @Override
    public void onStop() {
        super.onStop();

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
        Action viewAction = Action.newAction(
                Action.TYPE_VIEW, // TODO: choose an action type.
                "Login Page", // TODO: Define a title for the content shown.
                // TODO: If you have web page content that matches this app activity's content,
                // make sure this auto-generated web page URL is correct.
                // Otherwise, set the URL to null.
                Uri.parse("http://host/path"),
                // TODO: Make sure this auto-generated app URL is correct.
                Uri.parse("android-app://com.beidouapp.asdkdemo/http/host/path")
        );
        AppIndex.AppIndexApi.end(client, viewAction);
        client.disconnect();
    }

    private class MyBroadCaseReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (EtConstant.CONNECT_SUCCESS.equals(action)) {
                if (mydialog != null) {
                    mydialog.dismiss();
                }
                ToastUtil.showToast(context, "连接服务器成功");
                if (isTest) {//性能测试
                    Intent intentLogin = new Intent(LoginActivity.this,
                            PublishActivity.class);
                    startActivity(intentLogin);
                } else {
                    Intent intentLogin = new Intent(LoginActivity.this,
                            MainActivity.class);
                    intentLogin.putExtra(EtConstant.CONNECT_SERVER_IP,
                            intent.getStringExtra(EtConstant.CONNECT_SERVER_IP));
                    startActivity(intentLogin);
                }
                // Intent intentLogin = new Intent(LoginActivity.this,
                // PublishActivity.class);
                // startActivity(intentLogin);
                finish();
            } else if (EtConstant.CONNECT_FAILURE.equals(action)) {
                if (mydialog != null) {
                    mydialog.dismiss();
                }
                String log = intent.getStringExtra(EtConstant.ERROR);
                if (!log.equals("")) {
                    ToastUtil.showToast(context,
                            intent.getStringExtra(EtConstant.ERROR));
                } else {
                    ToastUtil.showToast(context, "连接服务器失败 ");
                }

            } else if (EtConstant.REGIST_SUCCESS.equals(action)) {
                Log.d("test", "regist success");
                String userId = intent.getStringExtra(EtConstant.USER_ID);
                et_user_id.setText(userId);
                ToastUtil.showToast(context, "注册成功,账号：" + userId,
                        Toast.LENGTH_LONG);
                llay_register.setVisibility(View.GONE);
            } else if (EtConstant.REGIST_FAILURE.equals(action)) {
                ToastUtil.showToast(context,
                        "注册失败," + intent.getStringExtra(EtConstant.ERROR),
                        Toast.LENGTH_LONG);
            }
        }
    }
}
