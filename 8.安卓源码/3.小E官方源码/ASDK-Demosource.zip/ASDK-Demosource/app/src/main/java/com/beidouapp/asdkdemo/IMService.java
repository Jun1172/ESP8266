package com.beidouapp.asdkdemo;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.text.format.Formatter;
import android.util.Log;

import com.beidouapp.config.EtConstant;
import com.beidouapp.et.ConnectOptions;
import com.beidouapp.et.ErrorInfo;
import com.beidouapp.et.IActionListener;
import com.beidouapp.et.IFriendsActionListener;
import com.beidouapp.et.ISDKContext;
import com.beidouapp.et.ISDKContextCallback;
import com.beidouapp.et.Message;
import com.beidouapp.et.MessageType;
import com.beidouapp.et.SDKContextManager;
import com.beidouapp.et.SDKContextParameters;
import com.beidouapp.et.Server;
import com.beidouapp.et.client.domain.DocumentInfo;
import com.beidouapp.et.client.domain.UserInfo;
import com.beidouapp.utils.HexUtil;
import com.beidouapp.utils.TestUtil;
import com.google.gson.Gson;

public class IMService extends Service {

    private final String TAG = IMService.class.getName();
    public ISDKContext sdkContext;
    private Context mContext = IMService.this;
    private MyBinder mBinder = new MyBinder();
    private SharedPreferences sp;

    private String userId = "";

    /**
     * 可用的服务
     */
    private Server server = null;

    @Override
    public void onCreate() {
        super.onCreate();
        sp = getSharedPreferences(EtConstant.SHARE_PREFERENCE,
                Context.MODE_PRIVATE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (intent.getBooleanExtra(EtConstant.IS_RIGISTER, false)) {// 注册
            registUser(intent.getStringExtra(EtConstant.USER_NAME));
        } else {// 登录
            userId = sp.getString(EtConstant.USER_ID, "");
            SDKContextParameters sdkContextParameters = new SDKContextParameters();
            sdkContextParameters.setUid(userId);
            sdkContextParameters.setAppKey(sp.getString(EtConstant.ET_APP_KEY,
                    ""));
            sdkContextParameters.setSecretKey(sp.getString(
                    EtConstant.ET_SECRET_KEY, ""));
            sdkContextParameters.setBlanceServerAddress(sp.getString(
                    EtConstant.SERVERADD, ""));
            sdkContextParameters.setBlanceServerPort(Integer.parseInt(sp
                    .getString(EtConstant.PORT, "8085")));
            // sdkContextParameters.setLocalIp(getLocalIPAddress(mContext));

            sdkContext = SDKContextManager.createContext(sdkContextParameters);
            sdkContext.setCallback(setContextCallback());
            discoverSvrs();
        }
        return super.onStartCommand(intent, flags, startId);
    }

    private ISDKContextCallback setContextCallback() {
        return new ISDKContextCallback() {

            @Override
            public void onServer(Server svr) {
                server = svr;
                // 发现可用的服务器
                Log.i("test", "discover server success" + svr.getIp());
                connectSvrs(svr);

            }

            @Override
            public void onPeerState(String uid, String code) {
                // 用户状态改变
                Intent intent = new Intent(EtConstant.GET_FRIEND_STATUS);
                intent.putExtra(EtConstant.FRIEND_ID, uid);
                intent.putExtra(EtConstant.FRIEND_STATUS_CODE, code);
                sendBroadcast(intent);
                Log.d("test", userId + "的状态" + code);
            }

            @Override
            public void onMessage(MessageType type, String topic,
                                  Message message) {
                Log.d("test", "topic:" + topic + ";message.getPayload():"
                        + message.getPayload());
                TestUtil.showTest("！！！！！！！！！！！！" + message.getPayload().toString());
                // 接收到新消息
                Intent intent = new Intent(EtConstant.RECEIVE_MSG);
                //intent.putExtra("friendId", message.getSendUserId());
                intent.putExtra("msgType", type);
                intent.putExtra("msgTopic", topic);
                if (MainActivity.main_checkbox != null
                        && MainActivity.main_checkbox.isChecked()) {
                    intent.putExtra("msgContent",
                            HexUtil.byteArrayToHexStr(message.getPayload()));
                } else {
                    intent.putExtra("msgContent",
                            new String(message.getPayload()));
                }
                sendBroadcast(intent);
            }

            @Override
            public void onFileReceived(String sendId, DocumentInfo documentInfo) {
                // 有新的文件需要下载
                Log.i("zwt", "documentInfo:" + documentInfo);
                Gson gson = new Gson();
                String jsonStr = gson.toJson(documentInfo);
                Intent intent = new Intent(EtConstant.RECEIVE_FILE);

                intent.putExtra(EtConstant.SEND_ID, sendId);
                intent.putExtra(EtConstant.DOCUMENT_INFO, jsonStr);
                sendBroadcast(intent);

            }

            @Override
            public void onBroken(Server svr, int errorCode, String reason) {
                // 已经和服务器断开连接
                // if (errorCode == 1107) {//
                // Log.w("test", "用户被踢下线..");
                // Intent intent = new
                // Intent(EtConstant.CONNECT_LOST_REPEAT_LOGIN);
                // sendBroadcast(intent);
                // return;
                // }
                Intent intent = new Intent(EtConstant.CONNECT_LOST_OTHER_REASON);
                intent.putExtra(EtConstant.ERROR, "错误码：" + errorCode + ","
                        + reason);
                sendBroadcast(intent);

            }
        };
    }

    /**
     * 获取本地ip
     *
     * @param context
     * @return
     */
    private String getLocalIPAddress(Context context) {
        WifiManager wifiManager = (WifiManager) context
                .getSystemService(Context.WIFI_SERVICE);
        WifiInfo wifiInfo = wifiManager.getConnectionInfo();
        String ipAddress = FormatIP(wifiInfo.getIpAddress());
        return ipAddress;
    }

    public String FormatIP(int ip) {
        return Formatter.formatIpAddress(ip);
    }

    /**
     * 发现服务器
     */
    public void discoverSvrs() {
        sdkContext.discoverSvrs(10, new IActionListener() {

            @Override
            public void onSuccess() {
                // 正在扫描服务器，
                // 扫描到的服务器通过sdk全局回调返回。
                Log.i("test", "正在扫描服务器...");
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                // 扫描服务器失败
                Log.i("test", "扫描服务器失败：" + errorInfo.getReason() + ",---错误码:"
                        + errorInfo.getCode());
            }
        });
    }

    /**
     * 连接服务器
     *
     * @param svr
     */
    public void connectSvrs(final Server svr) {

        ConnectOptions connectOptions = new ConnectOptions(); // 连接参数
        connectOptions.setConnectionTimeout(10); // 连接超时时间
        connectOptions.setKeepAliveInterval((short) 60); // 与服务器的保活时间间隔
        if (sp.getBoolean(EtConstant.IS_SAVE_OFFLINE_MSG, false)) {
            connectOptions.setCleanSession(false); // 保存离线消息
        } else {
            connectOptions.setCleanSession(true);
        }

        // svr为discover发现到的可用服务器
        sdkContext.connect(svr, connectOptions, new IActionListener() {

            @Override
            public void onSuccess() {
                // 连接服务器成功
                Log.i("test", "server connect success");
                Intent intent = new Intent(EtConstant.CONNECT_SUCCESS);
                intent.putExtra(EtConstant.CONNECT_SERVER_IP, svr.getIp());
                sendBroadcast(intent);
                // subMenu("Fc5wGsTuvumomVom3rLRKHncjDjJteonRJ&TX");
                // subMenu("Fc5wGsTuvumomVom1TxJ4xfhxmH7MaZUq5&TX");// 测试
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                // 连接服务器失败

                Intent intent = new Intent(EtConstant.CONNECT_FAILURE);
                if (errorInfo != null) {
                    intent.putExtra(EtConstant.ERROR,
                            "error code:" + errorInfo.getCode()
                                    + ", error reason:" + errorInfo.getReason());
                    Log.i("test",
                            "server connect failure,error:"
                                    + errorInfo.getReason());
                }
                sendBroadcast(intent);
            }
        });
    }

    public void subMenu(String str) {
        sdkContext.subscribe(str, new IActionListener() {

            @Override
            public void onSuccess() {
                // TODO Auto-generated method stub
                TestUtil.showTest("订阅成功");
            }

            @Override
            public void onFailure(ErrorInfo arg0) {
                // TODO Auto-generated method stub
                TestUtil.showTest("订阅失败");
            }
        });
    }

    /**
     * 断开服务器连接
     */
    public void disconnectServer() {

        sdkContext.disconnect(server, new IActionListener() {

            @Override
            public void onSuccess() {
                // 断开连接成功
                Log.i("test", "server disconnect success");
                Intent intent = new Intent(EtConstant.DISCONNECT_SERVER_SUCCESS);
                sendBroadcast(intent);
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                // 断开连接失败
                Log.i("test", "server disconnect failure");
                Intent intent = new Intent(EtConstant.DISCONNECT_SERVER_FAILURE);
                intent.putExtra(EtConstant.ERROR, "错误：" + errorInfo.getCode()
                        + ":" + errorInfo.getReason());
                sendBroadcast(intent);
            }
        });
    }

    /**
     * 用户注册
     *
     * @param userName 用户名
     */
    public void registUser(String userName) {
        int port = Integer.parseInt(sp.getString(EtConstant.PORT, "8085"));
        SDKContextManager.registerUser(userName,
                sp.getString(EtConstant.SERVERADD, ""), port,
                sp.getString(EtConstant.ET_APP_KEY, ""),
                sp.getString(EtConstant.ET_SECRET_KEY, ""),
                new IFriendsActionListener() {

                    @Override
                    public void onSuccess() {
                        // 该方法不会调用
                    }

                    @Override
                    public void onFailure(final ErrorInfo e) {
                        // 注册用户失败
                        Log.i("test", "注册用户失败");
                        Intent intent = new Intent(EtConstant.REGIST_FAILURE);
                        intent.putExtra(EtConstant.ERROR, "错误" + e.getCode()
                                + "：" + e.getReason());
                        sendBroadcast(intent);
                    }

                    @Override
                    public void onResultData(final Object arg0) {
                        UserInfo userInfo = (UserInfo) arg0;
                        // 注册用户成功
                        Log.i("test", "注册用户成功");
                        Intent intent = new Intent(EtConstant.REGIST_SUCCESS);
                        intent.putExtra(EtConstant.USER_ID,
                                userInfo.getUserid());
                        sendBroadcast(intent);
                    }
                });
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO Auto-generated method stub
        return mBinder;
    }

    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
        super.onDestroy();
        if (sdkContext != null) {
            SDKContextManager.destroyContext(sdkContext);
        }
    }

    class MyBinder extends Binder {

        public ISDKContext isdkContext;

        /**
         * 初始化管理器
         */
        public void getSdkContext(Handler handler) {
            this.isdkContext = sdkContext;
        }

        public ISDKContext getContext() {
            return sdkContext;
        }

        /**
         * 断开服务器连接
         */
        public void disconnect() {
            disconnectServer();
        }

        /**
         * 停止服务
         */
        public void stopService() {
            stopSelf();
        }
    }

}
