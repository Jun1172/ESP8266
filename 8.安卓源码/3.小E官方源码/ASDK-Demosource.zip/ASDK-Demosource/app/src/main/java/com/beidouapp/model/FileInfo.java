package com.beidouapp.model;

import com.beidouapp.et.client.domain.DocumentInfo;

public class FileInfo {
	private String fileName;
	private String fileId;
	private String filePath;
	
	//文件是否下载
    private int downloadStatu;
	private DocumentInfo documentInfo ;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public DocumentInfo getDocumentInfo() {
		return documentInfo;
	}
	public void setDocumentInfo(DocumentInfo documentInfo) {
		this.documentInfo = documentInfo;
	}
	public int getDownloadStatu() {
		return downloadStatu;
	}
	public void setDownloadStatu(int downloadStatu) {
		this.downloadStatu = downloadStatu;
	}
}
