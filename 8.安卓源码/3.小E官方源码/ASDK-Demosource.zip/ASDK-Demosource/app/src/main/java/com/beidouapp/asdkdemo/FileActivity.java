package com.beidouapp.asdkdemo;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.beidouapp.config.EtConstant;
import com.beidouapp.et.ISDKContext;
import com.beidouapp.et.client.callback.FileCallBack;
import com.beidouapp.et.client.domain.DocumentInfo;
import com.beidouapp.model.FileInfo;
import com.beidouapp.utils.FileUtil;
import com.beidouapp.utils.ToastUtil;
import com.google.gson.Gson;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FileActivity extends Activity implements OnClickListener {

    /**
     * 默认文件存储路径.
     */
    public static final String DEFAULT_STORAGE_PATH = FileUtil.getDefaultFileStoragePath();
    /**
     * 文件状态是 查看还是下载
     */
    private static final String STATUS = "status";
    private static final String FILE_PATH = "filePath";
    private static final int FILE_SELECT_CODE = 0;
    public final String strDownload = "点击下载";
    public final String strSeeDetail = "点击查看";
    public final String strDownloading = "下载中";
    public final String strDownLoadFailure = "下载失败";
    private Button btn_send_file, btn_receive_offline_file;
    private ListView listview_log;
    private TextView tv_toast;
    private EditText et_friend_id;
    private ScrollView scroll_view;
    private int scrolledX = 0;
    private int scrolledY = 0;
    private String friendId = "";
    /**
     * 文件路径
     */
    private String filePath = "";
    /**
     * 是否发送文件
     */
    private boolean isSendFile = false;
    private IMService.MyBinder mBinder;
    private ISDKContext sdkContext;
    private List<FileInfo> listFileInfo = new ArrayList<FileInfo>();
    private List<Map<String, Object>> listFile = new ArrayList<Map<String, Object>>();
    private SimpleAdapter mAdapter = null;
    private StringBuilder results = new StringBuilder();

    private MyBroadcaseReceiver rec = null;

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBinder = (IMService.MyBinder) service;
            mBinder.getSdkContext(null);
            sdkContext = mBinder.isdkContext;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file);
        initView();

        registerBroadcase();

        // 绑定服务
        Intent intent = new Intent(this, IMService.class);
        intent.putExtra(EtConstant.IS_RIGISTER, false);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);

    }

    @Override
    protected void onResume() {
        if (isSendFile) {
            sendFile();
        }
        isSendFile = false;
        super.onResume();
    }

    public void initView() {
        btn_send_file = (Button) findViewById(R.id.btn_send_file);
        btn_send_file.setOnClickListener(this);

        btn_receive_offline_file = (Button) findViewById(R.id.btn_receive_offline_file);
        btn_receive_offline_file.setOnClickListener(this);

        scroll_view = (ScrollView) findViewById(R.id.scroll_view);
        tv_toast = (TextView) findViewById(R.id.tv_toast);

        et_friend_id = (EditText) findViewById(R.id.et_friend_id);

    }

    public void setListviewData() {
        if (listFile != null) {
            if (listFile.size() > 0) {
                listview_log = (ListView) findViewById(R.id.listview_log);
                mAdapter = new SimpleAdapter(this, listFile, R.layout.list_file,
                        new String[]{FILE_PATH, STATUS},
                        new int[]{R.id.tv_file_path, R.id.tv_download});

                listview_log.setAdapter(mAdapter);
                listview_log.setOnItemClickListener(new OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        if (listFile.get(position).get(STATUS).equals(strSeeDetail)) {

                            // 指定路径(获取文件存储的路径)
                            File file = new File(listFile.get(position).get(FILE_PATH) + "");
                            if (file.exists()) {
                                FileUtil.openFile(getApplicationContext(), file);
                            } else {
                                ToastUtil.showToast(getApplicationContext(), "文件已被移除！");

                                // Intent intent = new Intent();
                                // intent.setAction(android.content.Intent.ACTION_VIEW);
                                // intent.setDataAndType(Uri.fromFile(file),
                                // "*/*");
                                // context.startActivity(intent);
                            }
                        } else if (listFile.get(position).get(STATUS).equals(strDownload)) {
                            listFile.get(position).put(STATUS, strDownloading);
                            setListviewData();
                            doDownLoadFile((DocumentInfo) listFile.get(position).get(EtConstant.DOCUMENT_INFO), position);
                        }
                    }
                });
            } else {
                mAdapter.notifyDataSetChanged();
            }

        }
    }

    /**
     * 发送内容
     *
     * @param filePath
     */
    public void sendFile() {

        // FileInfo fileInfo = new FileInfo();
        // fileInfo.setFilePath(filePath);

        Log.i("test", " im sdkContext:" + sdkContext);
        try {
            sdkContext.fileTo(friendId, filePath, new FileCallBack() {

                @Override
                public void onSuccess(final DocumentInfo documentInfo, final String fileFullPath) {
                    Log.i("test", "onSuccess fileFullPath:" + fileFullPath);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            results.append(
                                    "\n发送成功：\n文件名：" + documentInfo.getFileName() + "\n文件完整路径:" + fileFullPath + "\n");
                            showResult(results);

                            Map<String, Object> map = new HashMap<String, Object>();
                            map.put(FILE_PATH, fileFullPath);
                            map.put(STATUS, strSeeDetail);
                            listFile.add(map);
                            setListviewData();
                        }
                    });
                }

                @Override
                public void onProcess(final DocumentInfo documentInfo, final String fileFullPath,
                                      final long currentIndex, final long total) {
                    Log.i("test", "onProcess fileFullPath:" + fileFullPath + ",currentIndex：" + currentIndex + ",total："
                            + total);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            results.append("\n发送中：\n文件名：" + documentInfo.getFileName() + "\n文件完整路径:" + fileFullPath
                                    + "\n当前进度：" + currentIndex + "\n总的大小：" + total + "\n");
                            showResult(results);
                        }
                    });
                }

                @Override
                public void onFailure(final String fileFullPath, final Throwable throwable) {
                    Log.i("test", "onFailure fileFullPath:" + fileFullPath);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            results.append("\n发送失败：\n文件完整路径:" + fileFullPath + "\nerror:" + throwable.getMessage());
                            showResult(results);
                        }
                    });
                }
            });
        } catch (Exception e) {
            results.append("\n发送失败:" + "\nerror:" + e.getMessage());
            showResult(results);
        }
    }

    /**
     * 下载文件
     *
     * @param documentInfo
     * @param position
     */
    public void doDownLoadFile(final DocumentInfo documentInfo, final int position) {
        Log.i("test", "doDownLoadFile documentInfo:" + documentInfo);
        try {
            //sdkContext.downloadFile(arg0, arg1, arg2);

            sdkContext.downloadFile(documentInfo, DEFAULT_STORAGE_PATH + documentInfo.getFileName(), new FileCallBack() {

                @Override
                public void onFailure(final String fileFullPath, final Throwable t) {
                    Log.i("test", "文件下载失败");
                    runOnUiThread(new Runnable() {
                        public void run() {
                            listFile.get(position).put(STATUS, strDownLoadFailure);
                            setListviewData();

                            results.append("\n文件下载失败：\n文件完整路径:" + fileFullPath + "\nerror:" + t.getMessage());
                            showResult(results);
                            listview_log.setSelection(position);
                        }
                    });
                }

                @Override
                public void onProcess(final DocumentInfo documentInfo, final String fileFullPath, final long currentIndex, final long total) {
                    Log.i("test", "doDownLoadFile onprocess:" + currentIndex);

                    runOnUiThread(new Runnable() {
                        public void run() {

                            listFile.get(position).put(STATUS, strDownloading + ":" + currentIndex + "/" + total);
                            setListviewData();
                            listview_log.setSelection(position);

                        }
                    });
                }

                @Override
                public void onSuccess(final DocumentInfo documentInfo, final String fileFullPath) {
                    Log.i("test", "文件下载完成    " + documentInfo);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            results.append(
                                    "\n文件下载成功：\n文件名：" + documentInfo.getFileName() + "\n文件完整路径:" + fileFullPath + "\n");
                            showResult(results);
                            listFile.get(position).put(FILE_PATH, fileFullPath);
                            listFile.get(position).put(STATUS, strSeeDetail);
                            setListviewData();
                            listview_log.setSelection(position);
                        }
                    });
                }
            });
            Log.i("test", "正在文件下载....");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.i("test", "onActivityResult");
        if (resultCode == Activity.RESULT_OK) {
            isSendFile = true;
            try {
                Uri uri = data.getData();
                filePath = uri.getPath();
                File f = new File(filePath);
                if (!f.isFile()) {
                    filePath = getUrlFromGallery(uri);
                }

                if (filePath == null || filePath.equals("null")) {
                    ToastUtil.showToast(getApplicationContext(), "找不到文件");
                    results.append("\n找不到文件\n");
                    showResult(results);
                    return;
                }
                Log.i("test", "发送文件给用户【" + friendId + "】, 文件filePath：" + filePath);
                results.append("\nto:" + friendId + "\n文件filePath：" + filePath + "\n");
                showResult(results);
            } catch (Exception e) {
                ToastUtil.showToast(getApplicationContext(), "发送文件给用户【" + friendId + "】失败!");
                Log.e("test", "发送文件给用户【" + friendId + "】, 发送文件：", e);
                results.append("\nto" + friendId + "】失败\nerror:" + e.getMessage() + "\n");
                showResult(results);
            }

        } else {
            isSendFile = false;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * 获取图库url
     *
     * @param selectedImage
     */
    private String getUrlFromGallery(Uri selectedImage) {
        Cursor cursor = getContentResolver().query(selectedImage, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
            int columnIndex = cursor.getColumnIndex("_data");
            String picturePath = cursor.getString(columnIndex);
            cursor.close();
            cursor = null;

            return picturePath;
        } else {
            File file = new File(selectedImage.getPath());
            return file.getAbsolutePath();
        }
    }

    /**
     * 展示操作结果
     *
     * @param results
     */
    public void showResult(StringBuilder results) {
        tv_toast.setText(results.toString());
        Handler handler = new Handler();
        handler.post(new Runnable() {

            @Override
            public void run() {
                scroll_view.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_send_file:
                friendId = et_friend_id.getText().toString();
                if (friendId.equals("")) {
                    ToastUtil.showToast(getApplicationContext(), "请输入好友id");
                    return;
                }
                filePath = "";
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(Intent.createChooser(intent, "请选择要发送的文件"), FILE_SELECT_CODE);
                } catch (android.content.ActivityNotFoundException ex) {
                    ToastUtil.showToast(this, "请安装文件管理器");
                }

                break;
            case R.id.btn_receive_offline_file:
                requestOfflineMessage();//每次登陆只会请求一次
                break;

            default:
                break;
        }
    }

    /**
     * 获取离线消息
     */
    public void requestOfflineMessage() {
        if (sdkContext != null) {
            try {
                sdkContext.requestOfflineMessage();// 向服务器主动获取离线消息.用户在线时，多次调用此方法时，服务器忽略.
            } catch (final Exception e) {
                e.printStackTrace();
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(), "获取离线消息失败\n" + e.getMessage());
                        results.append("\n获取离线消息失败\n" + e.getMessage() + "\n");
                        showResult(results);
                    }
                });
            }

        }

    }

    public void registerBroadcase() {
        rec = new MyBroadcaseReceiver();
        IntentFilter filter = new IntentFilter();
        filter.addAction(EtConstant.RECEIVE_FILE);
        filter.addAction(EtConstant.CONNECT_LOST_OTHER_REASON);
        registerReceiver(rec, filter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(connection);
//		if (mBinder != null) {
//			mBinder.stopService();
//		}
        if (rec != null) {
            unregisterReceiver(rec);
        }
    }

    private class MyBroadcaseReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (EtConstant.RECEIVE_FILE.equals(action)) {
                Gson gson = new Gson();
                DocumentInfo document = gson.fromJson(intent.getStringExtra(EtConstant.DOCUMENT_INFO), DocumentInfo.class);
                Map<String, Object> map = new HashMap<String, Object>();
                map.put(FILE_PATH, document.getFileName());
                map.put(STATUS, strDownload);
                map.put(EtConstant.DOCUMENT_INFO, document);
                listFile.add(map);
                setListviewData();
                results.append("\n接收到文件：from" + intent.getStringExtra(EtConstant.SEND_ID) + "\n文件名:" + document.getFileName() + "\n");
                showResult(results);
            } else if (EtConstant.CONNECT_LOST_OTHER_REASON.equals(action)) {
                results.append("\n您被踢下线，3s后跳转到登录页面\n");
                showResult(results);
                finish();
            }
        }

    }

}
