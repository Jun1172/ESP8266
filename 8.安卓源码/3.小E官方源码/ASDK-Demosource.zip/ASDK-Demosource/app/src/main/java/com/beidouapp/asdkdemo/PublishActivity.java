package com.beidouapp.asdkdemo;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.beidouapp.config.EtConstant;
import com.beidouapp.et.ErrorInfo;
import com.beidouapp.et.IActionListener;
import com.beidouapp.et.ISDKContext;
import com.beidouapp.utils.HexUtil;
import com.beidouapp.utils.TestUtil;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PublishActivity extends Activity {// 只包含publish消息的接收

    public static CheckBox publish_is_hex;
    final int CHAT_TO = 1, PUBLISH = 2, PUBLISHTOGROUP = 3;
    CheckBox xunhuan;
    EditText menu_data, jiange, changdu, data, uid, topic, groupId;
    TextView publish_result, menu_name;
    StringBuffer buffer = new StringBuffer();
    Button publish_msg, chatto, publish, publishtogroup;
    int count = 1;
    ScrollView mView;
    private IMService.MyBinder mBinder;
    private ISDKContext sdkContext;
    Handler sendHandler = new Handler() {
        @Override
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            String sss = jiange.getText().toString().trim();

            if (sss == null || sss.equals("")) {
                Toast.makeText(PublishActivity.this, "请输入间隔时间", Toast.LENGTH_SHORT).show();
                return;
            }
            int jiangeTime = Integer.parseInt(sss);
            String msgContent = data.getText().toString().trim();
            if (msg.what == CHAT_TO) {
                String friendID = uid.getText().toString().trim();
                chatTo(friendID, msgContent);
                if (xunhuan.isChecked()) {
                    sendEmptyMessageDelayed(CHAT_TO, jiangeTime);
                }
            } else if (msg.what == PUBLISH) {
                String topicID = topic.getText().toString().trim();
                publish(msgContent, topicID);
                if (xunhuan.isChecked()) {
                    sendEmptyMessageDelayed(PUBLISH, jiangeTime);
                }

            } else if (msg.what == PUBLISHTOGROUP) {
                String groupID = groupId.getText().toString().trim();
                publishToGroup(groupID, msgContent);
                if (xunhuan.isChecked()) {
                    sendEmptyMessageDelayed(PUBLISHTOGROUP, jiangeTime);
                }
            }

        }
    };
    View.OnClickListener myclick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            boolean isXunHuan = xunhuan.isChecked();
            String msgContent = data.getText().toString().trim();
            switch (v.getId()) {
                case R.id.chatto:
                    count = 1;
                    String friendID = uid.getText().toString().trim();

                    if (friendID == null || friendID.equals("")) {
                        Toast.makeText(PublishActivity.this, "输入UID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (checkDataIsNull()) return;
                    chatToIsXunHuan(isXunHuan, friendID, msgContent);
                    break;
                case R.id.publish:
                    count = 1;
                    String topicID = topic.getText().toString().trim();
                    if (topicID == null || topicID.equals("")) {
                        Toast.makeText(PublishActivity.this, "输入TOPIC", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (checkDataIsNull()) return;
                    publishIsXunHuan(isXunHuan, topicID, msgContent);
                    break;
                case R.id.publishtogroup:
                    count = 1;
                    String groupID = groupId.getText().toString().trim();
                    if (groupID == null || groupID.equals("")) {
                        Toast.makeText(PublishActivity.this, "输入groupID", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (checkDataIsNull()) return;
                    publishToGroupIsXunHuan(isXunHuan, groupID, msgContent);
                    break;
                default:
                    break;
            }
        }
    };
    private MyBroadcaseReceiver rec;
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {

        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {//
            mBinder = (IMService.MyBinder) service;
            // mBinder.getSdkContext(handler);
            sdkContext = mBinder.getContext();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.publish_layout);
        registBroadcase();
        init();
    }

    public void publish(String msgContent, String topic) {// publish
        boolean isHex = publish_is_hex.isChecked();
        com.beidouapp.et.Message msg = new com.beidouapp.et.Message();
        byte[] payload;
        if (isHex) {
            payload = HexUtil.hexStrToByteArray(exTrim(msgContent));
        } else {
            payload = msgContent.getBytes();
        }
        final String sendresult = addData(msgContent);
        if (sendresult.equals("no")) {
            return;
        }
        try {
            msg.setPayload(sendresult.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        sdkContext.publish(topic, 1, msg, new IActionListener() {

            @Override
            public void onSuccess() {
                // TODO Auto-generated method stub
                TestUtil.showTest("发送成功");
                showResult("\npublish成功" + "\n内容是： " + sendresult);
            }

            @Override
            public void onFailure(ErrorInfo arg0) {
                // TODO Auto-generated method stub
                TestUtil.showTest("发送失败");
                showResult("\npublish失败" + "\n");
            }
        });
        count++;
    }

    public void publishToGroup(String groupId, String msgContent) {
        com.beidouapp.et.Message msg = new com.beidouapp.et.Message();
        final String sendresult = addData(msgContent);
        if (sendresult.equals("no")) {
            return;
        }
        try {
            msg.setPayload(sendresult.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        sdkContext.publishToGroup(groupId, 1, msg, new IActionListener() {
            @Override
            public void onSuccess() {
                showResult("\npublishToGroup 成功  消息内容：\n" + sendresult);
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                showResult("\npublishToGroup 失败");
            }
        });
        count++;
    }


    public void publishToGroupIsXunHuan(boolean isXunHuan, String groupID, String msgContent) {
        if (isXunHuan) {
            sendHandler.sendEmptyMessage(PUBLISHTOGROUP);

        } else {
            publishToGroup(groupID, msgContent);
        }
    }

    public void init() {
        Intent intent = new Intent(this, IMService.class);
        // intent.putExtra(EtConstant.IS_RIGISTER, false);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);
        mView = (ScrollView) findViewById(R.id.publish_scroll);
        publish_is_hex = (CheckBox) findViewById(R.id.publish_is_hex);
        menu_data = (EditText) findViewById(R.id.menu_data);
        menu_name = (TextView) findViewById(R.id.menu_name);
        menu_name.setText("Fc5wGsTuvumomVom3rLRKHncjDjJteonRJ&RX");
        publish_msg = (Button) findViewById(R.id.publich_msg);
        publish_result = (TextView) findViewById(R.id.publish_result);
        xunhuan = (CheckBox) findViewById(R.id.xunhuan);
        jiange = (EditText) findViewById(R.id.jiange);
        changdu = (EditText) findViewById(R.id.changdu);
        data = (EditText) findViewById(R.id.data);
        uid = (EditText) findViewById(R.id.uid);
        topic = (EditText) findViewById(R.id.topic);
        groupId = (EditText) findViewById(R.id.groupid);
        chatto = (Button) findViewById(R.id.chatto);
        publish = (Button) findViewById(R.id.publish);
        publishtogroup = (Button) findViewById(R.id.publishtogroup);
        chatto.setOnClickListener(myclick);
        publish.setOnClickListener(myclick);
        publishtogroup.setOnClickListener(myclick);

        publish_msg.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {
                boolean isHex = publish_is_hex.isChecked();
                // TODO Auto-generated method stub
                String str = "^[A-Fa-f0-9]+$", data = menu_data.getText()
                        .toString().trim();
                Pattern p = Pattern.compile(str);
                Matcher m = p.matcher(data);
                if (isHex) {// 16进制
                    if (m.matches()) {
                        publish(menu_data.getText().toString().trim(),
                                "Fc5wGsTuvumomVom3rLRKHncjDjJteonRJ&RX");
                        // publish(menu_data.getText().toString().trim(),
                        // "Fc5wGsTuvumomVom1TxJ4xfhxmH7MaZUq5&RX");//测试
                    } else {
                        Toast.makeText(PublishActivity.this, "请输入正确的16进制数据",
                                Toast.LENGTH_SHORT).show();
                    }
                } else {// string
                    publish(menu_data.getText().toString().trim(),
                            "Fc5wGsTuvumomVom3rLRKHncjDjJteonRJ&RX");
                    // publish(menu_data.getText().toString().trim(),
                    // "Fc5wGsTuvumomVom1TxJ4xfhxmH7MaZUq5&RX");//测试
                }
            }
        });
    }

    private String exTrim(String str) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch == ' ') {
                continue;
            }
            sb.append(ch);
        }
        return sb.toString();
    }

    public void registBroadcase() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(EtConstant.GET_FRIEND_STATUS);
        filter.addAction(EtConstant.RECEIVE_MSG);
        filter.addAction(EtConstant.CONNECT_LOST_OTHER_REASON);
        filter.addAction(EtConstant.CONNECT_LOST_REPEAT_LOGIN);
        filter.addAction(EtConstant.DISCONNECT_SERVER_SUCCESS);
        filter.addAction(EtConstant.DISCONNECT_SERVER_FAILURE);
        filter.addAction(EtConstant.RECEIVE_FILE);
        rec = new MyBroadcaseReceiver();
        registerReceiver(rec, filter);
    }

    public void showResult(final String result) {// 展示收到的数据
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // TODO Auto-generated method stub
                buffer.append(result);
                publish_result.setText(buffer.toString());
                mView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }

    boolean checkDataIsNull() {
        String result = data.getText().toString().trim();
        if (result == null || result.equals("")) {//为空
            Toast.makeText(PublishActivity.this, "请输入要发送的内容", Toast.LENGTH_SHORT).show();
            return true;
        } else {
            return false;
        }
    }

    void chatToIsXunHuan(boolean isXunhuan, String friendID, String msgContent) {
        if (isXunhuan) {//循环发送
            sendHandler.sendEmptyMessage(CHAT_TO);
        } else {
            chatTo(friendID, msgContent);
        }
    }

    public String addData(String str) {
        StringBuffer buffer = new StringBuffer();
        buffer.append(System.currentTimeMillis() + "+" + count + "+" + str);
        String result = buffer.toString();
        if (changdu.getText().toString() == null || changdu.getText().toString().equals("")) {
            Toast.makeText(PublishActivity.this, "输入数据长度", Toast.LENGTH_SHORT).show();
            return "no";
        }
        int length = Integer.parseInt(changdu.getText().toString());
        if (result.length() < length) {
            buffer.append("+");
            int tiancong = length - result.length();
            for (int i = 0; i < tiancong; i++) {
                buffer.append("a");
            }
        }
        return buffer.toString();
    }


    void chatTo(String friendID, String msgContent) {
        com.beidouapp.et.Message message = new com.beidouapp.et.Message();

        final String sendresult = addData(msgContent);
        if (sendresult.equals("no")) {
            return;
        }
        try {
            message.setPayload(sendresult.getBytes("UTF-8"));
        } catch (UnsupportedEncodingException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        sdkContext.chatTo(friendID, message, new IActionListener() {
            @Override
            public void onSuccess() {//发送成功
                String sshow = sendresult;
                if (sendresult.length() > 25) {
                    sshow = sendresult.substring(0, 26);
                }
                String result = "\nchatSTo成功\n消息内容" + sshow;
                showResult(result);
            }

            @Override
            public void onFailure(ErrorInfo errorInfo) {
                String result = "chatTo失败\n";
                showResult(result);

            }
        });
        count++;
    }

    void publishIsXunHuan(boolean isXunHuan, String topicID, String msgContent) {
        if (isXunHuan) {
            sendHandler.sendEmptyMessage(PUBLISH);
        } else {
            publish(msgContent, topicID);
        }
    }

    public void writeLog(String result) {
        result = result + "\n";
        String filePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        File f = new File(filePath);
        if (!f.exists()) {
            f.mkdirs();
        }
        File file = new File(filePath + "/log.txt");
        if (!file.exists()) {//新建文件写入
            try {
                file.createNewFile();
                FileWriter writer = new FileWriter(file, true);
                writer.write(result);
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {//直接写文件
            try {
                FileWriter writer = new FileWriter(file, true);
                writer.write(result);
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (connection != null) {
            unbindService(connection);
        }
        unregisterReceiver(rec);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            mBinder.disconnect();
            if (mBinder != null) {
                mBinder.stopService();
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    private class MyBroadcaseReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (EtConstant.GET_FRIEND_STATUS.equals(action)) {
            } else if (EtConstant.RECEIVE_MSG.equals(action)) {
                StringBuffer sb = new StringBuffer();
                String msgContent = intent.getStringExtra("msgContent");
                if (msgContent.length() > 25) {
                    msgContent = msgContent.substring(0, 26);
                }
                sb.append(System.currentTimeMillis() + "," + intent.getStringExtra("msgTopic") + "," + intent.getStringExtra("msgContent").length() + "," + msgContent);
                showResult("\n收到消息：  " + sb.toString());
                writeLog(sb.toString());

            } else if (EtConstant.CONNECT_LOST_OTHER_REASON.equals(action)) {

            } else if (EtConstant.DISCONNECT_SERVER_SUCCESS.equals(action)) {

            } else if (EtConstant.DISCONNECT_SERVER_FAILURE.equals(action)) {
            } else if (EtConstant.RECEIVE_FILE.equals(action)) {
            }

        }

    }
}
