package com.beidouapp.config;

public class EtConstant {

    /**
     * App key. 413-427
     */
    public static final String APP_KEY = "4cdad356-85b4-008627";

    /**
     * 安全密钥. 413-427
     */
    public static final String SECRET_KEY = "c7147f6fea0daf6cbd36ed65b037b4c9";

    // public static final String SERVER_ADDRESS = "220.169.30.125" ;
    public static final String SERVER_ADDRESS = "115.28.226.129";
    public static final String SERVERADD = "server_add";
    public static final String PORT = "port";
    // public static final String SERVER_PORT_LB = "8085";
    /**
     * 登录用户id
     */
    public static final String USER_ID = "user_id";

    public static final String SEND_ID = "send_id";

    public static final String DOCUMENT_INFO = "dovument_info";

    /**
     * SharePreference key
     */
    public static final String SHARE_PREFERENCE = "share_preference";

    /**
     * 是否接收离线消息
     */
    public static final String IS_RECEIVE_OFFLINE_MSG = "is_receive_offline_msg";
    /**
     * 是否获取好友状态
     */
    public static final String IS_GET_FRIEND_STATUS = "is_get_friend_status";
    /**
     * 是否保存离线消息
     */
    public static final String IS_SAVE_OFFLINE_MSG = "is_save_offline_msg";
    /**
     * 获取好友状态
     */
    public static final String GET_FRIEND_STATUS = "get_friend_status";
    /**
     * 接收离线消息
     */
    public static final String RECEIVE_OFFLINE_MSG = "receive_offline_msg";
    /**
     * 好友状态code
     */
    public static final String FRIEND_STATUS_CODE = "user_status_code";
    /**
     * 好友id
     */
    public static final String FRIEND_ID = "friend_id";

    /**
     * 是否为注册
     */
    public static final String IS_RIGISTER = "is_register";
    /**
     * 用户名
     */
    public static final String USER_NAME = "user_name";

    /**
     * appkey
     */
    public static final String ET_APP_KEY = "app_key";
    /**
     * secret key
     */
    public static final String ET_SECRET_KEY = "secret_key";

    /**
     * 连接的服务器ip
     */
    public static final String CONNECT_SERVER_IP = "connect_server_ip";

    public static final String ERROR = "error";

    // ------------------------
    /**
     * 连接服务器成功
     */
    public static final String CONNECT_SUCCESS = "connect_success";
    /**
     * 连接服务器失败
     */
    public static final String CONNECT_FAILURE = "connect_failure";
    /**
     * 停止服务
     */
    public static final String STOP_SERVICE = "connect_failure";

    /**
     * 接收到消息
     */
    public static final String RECEIVE_MSG = "receive_msg";
    /**
     * 连接丢失,被踢下线
     */
    public static final String CONNECT_LOST_REPEAT_LOGIN = "connect_lost_repeat_login";
    /**
     * 连接丢失 ，其他原因
     */
    public static final String CONNECT_LOST_OTHER_REASON = "connect_lost_other_reason";

    /**
     * 注册成功
     */
    public static final String REGIST_SUCCESS = "regist_success";
    /**
     * 注册失败
     */
    public static final String REGIST_FAILURE = "regist_failure";

    public static final String DISCONNECT_SERVER_SUCCESS = "com.beidou.disconnect_success";

    public static final String DISCONNECT_SERVER_FAILURE = "com.beidou.disconnect_failure";

    /**
     * 接收文件
     */
    public static final String RECEIVE_FILE = "receive_file";

}
