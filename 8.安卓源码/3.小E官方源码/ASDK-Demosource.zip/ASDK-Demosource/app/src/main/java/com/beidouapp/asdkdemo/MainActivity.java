package com.beidouapp.asdkdemo;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.beidouapp.config.EtConstant;
import com.beidouapp.et.ErrorInfo;
import com.beidouapp.et.IActionListener;
import com.beidouapp.et.IFriendsActionListener;
import com.beidouapp.et.ISDKContext;
import com.beidouapp.et.client.domain.GroupInfo;
import com.beidouapp.et.client.domain.UserInfo;
import com.beidouapp.utils.HexUtil;
import com.beidouapp.utils.TestUtil;
import com.beidouapp.utils.ToastUtil;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity implements OnClickListener {

    /**
     * 请求好友列表成功
     */
    private static final int FRIEND_LIST_REQUEST_SUCCESS = 10001;
    /**
     * 创建群
     */
    private static final int CREATE_GROUP = 30001;
    /**
     * 获取群列表
     */
    private static final int GET_GROUPS = 30002;
    /**
     * 获取群成员成功
     */
    private static final int GET_GROUP_MEMBERS = 30003;
    public static CheckBox main_checkbox;
    /**
     * 群好友列表
     */
    List<UserInfo> listGroupMember = null;
    /**
     * 展示群详细信息对话框
     *
     * @param member
     * @param listGroupMember
     */
    int i = 1;
    boolean isFist = true;
    private Button btn_get_friends, btn_add_friend, btn_delete_friend,
            btn_send_msg, btn_register_offline_msg, reconnect_server,
            btn_disconnect_server, btn_create_group, btn_get_groups,
            btn_publish, btn_state_unsubscribe, btn_subscribe, btn_unsubscribe,
            btn_state_subscribe, btn_send_file;
    private TextView tv_toast;
    private EditText et_friend_id, et_friend_id_for_send, et_msg,
            et_subscribe_topic;
    private ScrollView scroll_view;
    private Spinner spinner_groups;
    private ArrayAdapter<String> adapter = null;
    private IMService.MyBinder mBinder;
    private StringBuilder results = new StringBuilder();
    private MyBroadcaseReceiver rec;
    /**
     * 所有好友id 数组
     */
    private String[] friendID = null;
    /**
     * 要添加或删除的群好友集合
     */
    private List<String> friendsForCreateGroup = new ArrayList<String>();
    /**
     * 登录用户id
     */
    private String userId = "";
    /**
     * 好友列表
     */
    private List<UserInfo> userInfoList = null;
    /**
     * sdk context
     */
    private ISDKContext sdkContext;
    /**
     * 选中查看的群topic
     */
    private String groupId;
    /**
     * 选中查看的群名称
     */
    private String groupName;
    private Dialog dialog = null;
    Handler handler = new Handler() {
        public void handleMessage(Message msg) {

            switch (msg.what) {
                case FRIEND_LIST_REQUEST_SUCCESS:
                    ToastUtil.showToast(MainActivity.this, "请求好友列表成功");
                    List<UserInfo> listFriendId = (List<UserInfo>) msg.obj;
                    int size = listFriendId.size();
                    if (size > 0) {
                        results.append("\n好友请求成功 ,id列表:\n");
                        for (int i = 0; i < size; i++) {
                            results.append(listFriendId.get(i).toString()).append(
                                    "\n");
                        }
                    } else {
                        results.append("\n你还没有好友，去添加几个吧\n");
                    }
                    showResult(results);

                    break;

                case CREATE_GROUP:
                    GroupInfo groupInfo = (GroupInfo) msg.obj;
                    if (groupInfo != null) {
                        spinner_groups.setVisibility(View.GONE);// 创建成功后隐藏群下拉列表(重新去请求一次),
                        results.append("\n创建群成功\n群名:" + groupInfo.getGroupname()
                                + "\n群topic:" + groupInfo.getTopic() + "\n");
                        ToastUtil.showToast(getApplicationContext(), "创建成功"
                                + groupInfo);
                    } else {
                        ToastUtil.showToast(getApplicationContext(), "没有返回群信息");
                        results.append("\n没有返回群信息\n");
                    }
                    showResult(results);

                    if (friendsForCreateGroup != null) {
                        friendsForCreateGroup.clear();
                    }
                    friendID = new String[]{};
                    break;

                case GET_GROUPS:// 获取群列表·
                    List<GroupInfo> groups = (List<GroupInfo>) msg.obj;
                    int size1 = groups.size();
                    if (groups != null && size1 > 0) {
                        String[] arrGroup = new String[size1 + 1];
                        results.append("\n群列表:\n");
                        for (int i = 0; i < size1; i++) {
                            if (i == 0) {
                                arrGroup[i] = "请选择群";
                            }
                            results.append("群名:" + groups.get(i).getGroupname()
                                    + "------群id:" + groups.get(i).getTopic()
                                    + "\n\n");
                            arrGroup[(i + 1)] = groups.get(i).getGroupname();
                        }
                        spinner_groups.setVisibility(View.VISIBLE);
                        setSpinnerGroups(arrGroup, groups);
                    } else {
                        results.append("\n没有群，去创建一个吧\n");
                        spinner_groups.setVisibility(View.GONE);
                    }
                    showResult(results);
                    break;

                case GET_GROUP_MEMBERS:
                    List<UserInfo> groupMember = (List<UserInfo>) msg.obj;
                    int length = groupMember.size();
                    String[] member = new String[length];
                    if (length <= 0) {
                        results.append("\n暂时没有群成员\n");
                    } else {
                        results.append("\n群成员:");
                        for (int i = 0; i < member.length; i++) {
                            results.append("\n" + groupMember.get(i) + "\n");
                            member[i] = groupMember.get(i).getUserid();
                        }
                    }
                    showResult(results);
                    if (isFist) {
                        showGroupInfoDialog(member, groupMember);
                    }

                    break;

                default:
                    break;
            }
        }
    };
    private ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBinder = (IMService.MyBinder) service;
            mBinder.getSdkContext(handler);
            sdkContext = mBinder.isdkContext;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sp = getSharedPreferences(
                EtConstant.SHARE_PREFERENCE, Context.MODE_PRIVATE);
        userId = sp.getString(EtConstant.USER_ID, "");
        registBroadcase();
        init();

        Intent intent = getIntent();
        String serverIp = intent.getStringExtra(EtConstant.CONNECT_SERVER_IP);
        results.append("\n连接上的服务器ip为:" + serverIp + "\n");
        showResult(results);
    }

    // ----------------------------------------------------------------------

    /**
     * 初始化view
     */
    public void init() {
        // 绑定服务
        Intent intent = new Intent(this, IMService.class);
        intent.putExtra(EtConstant.IS_RIGISTER, false);
        bindService(intent, connection, Context.BIND_AUTO_CREATE);

        // -------请求好友列表---------
        btn_get_friends = (Button) findViewById(R.id.btn_get_friends);
        btn_get_friends.setOnClickListener(this);

        // ------接收离线消息------
        btn_register_offline_msg = (Button) findViewById(R.id.btn_register_offline_msg);
        btn_register_offline_msg.setOnClickListener(this);

        reconnect_server = (Button) findViewById(R.id.btn_reconnect_server);
        reconnect_server.setOnClickListener(this);

        btn_disconnect_server = (Button) findViewById(R.id.btn_disconnect_server);
        btn_disconnect_server.setOnClickListener(this);

        btn_create_group = (Button) findViewById(R.id.btn_create_group);
        btn_create_group.setOnClickListener(this);
        btn_get_groups = (Button) findViewById(R.id.btn_get_groups);
        btn_get_groups.setOnClickListener(this);

        // ---------增删好友-------------
        btn_add_friend = (Button) findViewById(R.id.btn_add_friend);
        btn_add_friend.setOnClickListener(this);

        btn_delete_friend = (Button) findViewById(R.id.btn_delete_friend);
        btn_delete_friend.setOnClickListener(this);

        et_friend_id = (EditText) findViewById(R.id.et_friend_id);

        // ---------发送消息---------
        btn_send_msg = (Button) findViewById(R.id.btn_send_msg);
        btn_send_msg.setOnClickListener(this);
        et_msg = (EditText) findViewById(R.id.et_msg);
        et_friend_id_for_send = (EditText) findViewById(R.id.et_friend_id_for_send);

        scroll_view = (ScrollView) findViewById(R.id.scroll_view);
        tv_toast = (TextView) findViewById(R.id.tv_toast);

        // ---------用户状态订阅，取消---------
        btn_state_unsubscribe = (Button) findViewById(R.id.btn_state_unsubscribe);
        btn_state_unsubscribe.setOnClickListener(this);

        btn_state_subscribe = (Button) findViewById(R.id.btn_state_subscribe);
        btn_state_subscribe.setOnClickListener(this);

        // --------订阅发布主题----------
        btn_publish = (Button) findViewById(R.id.btn_publish);
        btn_publish.setOnClickListener(this);

        btn_unsubscribe = (Button) findViewById(R.id.btn_unsubscribe);
        btn_unsubscribe.setOnClickListener(this);

        et_subscribe_topic = (EditText) findViewById(R.id.et_subscribe_topic);

        btn_subscribe = (Button) findViewById(R.id.btn_subscribe);
        btn_subscribe.setOnClickListener(this);

        btn_send_file = (Button) findViewById(R.id.btn_send_file);
        btn_send_file.setOnClickListener(this);

        spinner_groups = (Spinner) findViewById(R.id.spinner_groups);
        main_checkbox = (CheckBox) findViewById(R.id.main_checkbox);
    }

    /**
     * 获取好友列表
     */
    private void getFriends() {
        sdkContext.getAllBuddies(new IFriendsActionListener() {

            @Override
            public void onSuccess() {
                // 该方法不会调用
            }

            @Override
            public void onFailure(final ErrorInfo e) {
                // 获取好友列表失败
                Log.e("test", "getFriends failure ,error code" + e.getCode()
                        + "e.getReason()" + e.getReason());
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(MainActivity.this, "请求好友列表失败 ");
                        results.append("\n请求好友列表失败:\n错误" + e.getCode() + ":"
                                + e.getReason());
                        showResult(results);
                    }
                });
            }

            @Override
            public void onResultData(Object arg0) {
                // 获取好友列表成功
                userInfoList = (List<UserInfo>) arg0;
                Message msg = new Message();
                msg.what = FRIEND_LIST_REQUEST_SUCCESS;
                msg.obj = userInfoList;
                handler.sendMessage(msg);
                SharedPreferences sp = getSharedPreferences(
                        EtConstant.SHARE_PREFERENCE, Context.MODE_PRIVATE);
                if (sp.getBoolean(EtConstant.IS_GET_FRIEND_STATUS, false)) {
                    peerState(userInfoList);
                }

            }
        });
    }

    /**
     * 获取指定用户的在线状态
     *
     * @param userInfoList 好友列表
     */
    public void peerState(List<UserInfo> userInfoList) {
        int size = userInfoList.size();
        for (int i = 0; i < size; i++) {
            try {
                sdkContext.peerState(userInfoList.get(i).getUserid(),
                        new IActionListener() {

                            @Override
                            public void onSuccess() {
                                Log.d("test", "peer state Success");
                            }

                            @Override
                            public void onFailure(ErrorInfo e) {
                                Log.d("test",
                                        "peer state failure,error code:"
                                                + e.getCode() + "error reason:"
                                                + e.getReason());
                            }
                        });
            } catch (Exception e) {
                e.printStackTrace();
                Log.e("test", "peerState():" + e.getMessage());
            }
        }
    }

    /**
     * 请求获取离线消息
     */
    public void requestOfflineMessage() {
        if (sdkContext != null) {
            try {
                sdkContext.requestOfflineMessage();
            } catch (Exception e) {
                // TODO: handle exception
                ToastUtil.showToast(getApplicationContext(),
                        "请求离线消息异常,可能与服务器断开了");
            }

        } else {
            ToastUtil.showToast(getApplicationContext(), "与服务器连接断开，请重新登录");
        }

    }

    /**
     * 订阅好友状态
     */
    public void stateSubscribe(String id) {

        try {
            sdkContext.stateSubscribe(id, new IActionListener() {

                @Override
                public void onSuccess() {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            ToastUtil.showToast(getApplicationContext(),
                                    "订阅好友状态成功");
                            results.append("\n订阅好友状态成功\n");
                            showResult(results);
                        }
                    });
                }

                @Override
                public void onFailure(final ErrorInfo e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            results.append("\n订阅好友状态失败;错误码:" + e.getCode()
                                    + ",错误原因：" + e.getReason() + "\n");
                            showResult(results);
                            ToastUtil.showToast(getApplicationContext(),
                                    "订阅好友状态失败;错误码:" + e.getCode() + ",错误原因："
                                            + e.getReason());
                        }
                    });
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            Log.i("test", "stateSubscribe:" + e.getMessage());
            ToastUtil.showToast(getApplicationContext(),
                    "订阅异常:" + e.getMessage());
        }

    }

    /**
     * 取消订阅好友状态
     */
    public void stateUnsubscribe(String id) {
        try {
            sdkContext.stateUnsubscribe(id, new IActionListener() {

                @Override
                public void onSuccess() {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            ToastUtil.showToast(getApplicationContext(),
                                    "取消订阅好友状态成功");
                            results.append("\n取消订阅好友状态成功\n");
                            showResult(results);
                        }
                    });
                }

                @Override
                public void onFailure(final ErrorInfo e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            ToastUtil.showToast(getApplicationContext(),
                                    "取消订阅好友状态失败,错误码:" + e.getCode() + ",错误原因："
                                            + e.getReason());
                            results.append("\n取消订阅好友状态失败\n错误码:" + e.getCode()
                                    + ",错误原因：" + e.getReason() + "\n");
                            showResult(results);
                        }
                    });
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
            ToastUtil.showToast(getApplicationContext(),
                    "取消订阅异常：" + e.getMessage());
        }
    }

    /**
     * 添加好友
     */
    public void addBuddy(String friendId) {
        if (friendId.equals("")) {
            ToastUtil.showToast(getApplicationContext(), "请输入你要添加的好友id");
            return;
        }
        sdkContext.addBuddy(friendId, new IFriendsActionListener() {

            @Override
            public void onSuccess() {
                // 添加好友成功
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(), "添加好友成功");
                        results.append("\n添加好友成功\n");
                        showResult(results);
                    }
                });
            }

            @Override
            public void onResultData(Object data) {
                // 该方法不会调用
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 添加好友失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "添加好友失败,错误码:" + errorInfo.getCode() + ","
                                        + errorInfo.getReason());
                        results.append("\n添加好友失败:\n错误码:").append(
                                errorInfo.getCode() + ","
                                        + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });
            }
        });
    }

    /**
     * 添加好友通知对方已被其他人添加为好友
     */
    public void addBuddyNotify(String friendId) {

        if (friendId.equals("")) {
            ToastUtil.showToast(getApplicationContext(), "请输入你要添加的好友id");
            return;
        }
        sdkContext.addBuddyNotify(friendId, new IFriendsActionListener() {

            @Override
            public void onSuccess() {
                // 添加好友成功
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(), "添加好友成功");
                        results.append("\n添加好友成功\n");
                        showResult(results);
                    }
                });
            }

            @Override
            public void onResultData(Object data) {
                // 该方法不会调用
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 添加好友失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "添加好友失败,错误码:" + errorInfo.getCode() + ","
                                        + errorInfo.getReason());
                        results.append("\n添加好友失败:\n错误码:").append(
                                errorInfo.getCode() + ","
                                        + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });
            }
        }, true);
    }

    /**
     * 删除好友
     */
    public void removeBuddy(String friendId) {
        if (friendId.equals("")) {
            ToastUtil.showToast(getApplicationContext(), "请输入你要删除的好友id");
            return;
        }

        sdkContext.removeBuddy(friendId, new IFriendsActionListener() {

            @Override
            public void onSuccess() {
                // 删除好友成功
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(), "删除好友成功");
                        results.append("\n删除好友成功\n");
                        showResult(results);
                    }
                });
            }

            @Override
            public void onResultData(Object data) {
                // 该方法不会调用
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 删除好友失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "删除好友失败,错误码:" + errorInfo.getCode() + ","
                                        + errorInfo.getReason());
                        results.append("\n删除好友失败:\n错误码:").append(
                                errorInfo.getCode() + ","
                                        + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });
            }
        });
    }

    /**
     * 删除好友通知对方已经被其他人删除
     */
    public void removeBuddyNotify(String friendId) {
        if (friendId.equals("")) {
            ToastUtil.showToast(getApplicationContext(), "请输入你要删除的好友id");
            return;
        }

        sdkContext.removeBuddyNotify(friendId, new IFriendsActionListener() {

            @Override
            public void onSuccess() {
                // 删除好友成功
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(), "删除好友成功");
                        results.append("\n删除好友成功\n");
                        showResult(results);
                    }
                });
            }

            @Override
            public void onResultData(Object data) {
                // 该方法不会调用
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 删除好友失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "删除好友失败,错误码:" + errorInfo.getCode() + ","
                                        + errorInfo.getReason());
                        results.append("\n删除好友失败:\n错误码:").append(
                                errorInfo.getCode() + ","
                                        + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });
            }
        }, true);
    }

    private String exTrim(String str) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (ch == ' ') {
                continue;
            }
            sb.append(ch);
        }
        return sb.toString();
    }

    /**
     * 发送消息
     */
    public void chatTo() {
        String msgContent = et_msg.getText().toString();
        String friendId = et_friend_id_for_send.getText().toString();
        if (friendId.equals("") || msgContent.equals("")) {
            ToastUtil.showToast(getApplicationContext(), "请把好友id和消息内容都填好再发");
            return;
        }
        com.beidouapp.et.Message message = new com.beidouapp.et.Message();
        boolean isHex = main_checkbox.isChecked();
        String str = "^[A-Fa-f0-9]+$", data = msgContent
                .toString().trim();
        Pattern p = Pattern.compile(str);
        Matcher m = p.matcher(data);
        if (!m.matches() && isHex) {
            Toast.makeText(MainActivity.this, "请输入正确的16进制数据",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        byte[] payload;
        if (isHex) {
            payload = HexUtil.hexStrToByteArray(exTrim(msgContent));
        } else {
            payload = msgContent.getBytes();
        }

        message.setPayload(payload);
        sdkContext.chatTo(friendId, message, new IActionListener() {

            @Override
            public void onSuccess() {
                // 代表消息成功发送到服务器，不表示接收方已经收到消息。
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "发送消息到服务器成功");
                        results.append("\n发送消息到服务器成功\n");
                        showResult(results);
                    }
                });
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 发送失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "发送消息失败,错误码:" + errorInfo.getCode() + ","
                                        + errorInfo.getReason());
                        results.append("\n发送消息失败:\n错误码:").append(
                                errorInfo.getCode() + ","
                                        + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });
            }
        });
    }

    /**
     * 创建群
     *
     * @param groupName  群名字
     * @param userIdList 要添加的好友id列表
     */
    public void createGroup(String groupName, List<String> userIdList) {

        if (userInfoList == null) {
            ToastUtil.showToast(getApplicationContext(), "你没有选择任何要添加的好友");
            return;
        }
        sdkContext.createGroup(groupName, userIdList,
                new IFriendsActionListener() {

                    @Override
                    public void onSuccess() {
                        // 该方法不会调用
                    }

                    @Override
                    public void onResultData(Object data) {
                        // GroupInfo groupInfo = (GroupInfo) data;
                        Message msg = new Message();
                        msg.what = CREATE_GROUP;
                        msg.obj = (GroupInfo) data;
                        handler.sendMessage(msg);

                    }

                    @Override
                    public void onFailure(final ErrorInfo errorInfo) {
                        // 创建群失败
                        runOnUiThread(new Runnable() {
                            public void run() {
                                canCloseDialog(dialog, true);
                                ToastUtil.showToast(getApplicationContext(),
                                        "创建群失败," + errorInfo.getCode() + ","
                                                + errorInfo.getReason());
                                results.append("\n创建群失败：\n错误码："
                                        + errorInfo.getCode() + ","
                                        + errorInfo.getReason() + "\n");
                                showResult(results);
                            }
                        });
                    }
                });
    }

    /**
     * 获取群列表
     */
    public void getAllGroups() {

        sdkContext.getAllGroups(new IFriendsActionListener() {

            @Override
            public void onSuccess() {
                // 该方法不会调用
            }

            @Override
            public void onResultData(Object data) {
                List<GroupInfo> groupInfoList = (List<GroupInfo>) data;
                // 返回该用户的所有群信息
                Message msg = new Message();
                msg.what = GET_GROUPS;
                msg.obj = groupInfoList;
                handler.sendMessage(msg);
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 查询群消息失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        spinner_groups.setVisibility(View.GONE);
                        ToastUtil.showToast(getApplicationContext(), "获取群列表失败");
                        results.append("\n获取群列表失败：\n" + errorInfo.getCode()
                                + "," + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });
            }
        });
    }

    /**
     * 获取群全部成员
     *
     * @param groupId
     * @param listGroups
     */
    public void getAllGroupMembers(String groupId, List<GroupInfo> listGroups) {

        sdkContext.getAllGroupMembers(groupId, new IFriendsActionListener() {

            @Override
            public void onSuccess() {
                // 该方法不会调用
            }

            @Override
            public void onResultData(Object data) {
                listGroupMember = (List<UserInfo>) data;
                // 返回群成员列表
                Message msg = new Message();
                msg.what = GET_GROUP_MEMBERS;
                msg.obj = listGroupMember;
                handler.sendMessage(msg);
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 查询群成员失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "获取群成员失败！失败：" + errorInfo.getCode() + ","
                                        + errorInfo.getReason());
                        results.append("\n获取群成员失败\n错误：" + errorInfo.getCode()
                                + "\n" + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });

            }
        });
    }

    /**
     * 添加群成员
     */
    public void addGroupMember() {
        sdkContext.addGroupMember(groupId, friendsForCreateGroup,
                new IFriendsActionListener() {

                    @Override
                    public void onSuccess() {

                        // 添加群成员成功
                        runOnUiThread(new Runnable() {
                            public void run() {
                                ToastUtil.showToast(getApplicationContext(),
                                        "添加群成员成功，请关闭对话框重新获取群列表",
                                        Toast.LENGTH_LONG);
                                results.append("\n添加群成员成功\n");
                                showResult(results);
                                if (dialog != null) {
                                    dialog.dismiss();
                                }
                                spinner_groups.setVisibility(View.GONE);

                            }
                        });
                    }

                    @Override
                    public void onResultData(Object data) {
                        // 该方法不会调用
                    }

                    @Override
                    public void onFailure(final ErrorInfo errorInfo) {
                        // 添加群成员失败
                        runOnUiThread(new Runnable() {
                            public void run() {
                                ToastUtil.showToast(getApplicationContext(),
                                        "添加群成员失败：\n" + errorInfo.getCode()
                                                + "," + errorInfo.getReason()
                                                + "\n");
                                results.append("\n添加群成员失败：\n"
                                        + errorInfo.getCode() + ","
                                        + errorInfo.getReason() + "\n");
                                showResult(results);
                            }
                        });
                    }
                });
    }

    /**
     * 删除群成员
     */
    public void removeGroupMember() {
        sdkContext.removeGroupMember(groupId, friendsForCreateGroup,
                new IFriendsActionListener() {

                    @Override
                    public void onSuccess() {
                        // 删除群成员成功
                        runOnUiThread(new Runnable() {
                            public void run() {
                                ToastUtil.showToast(getApplicationContext(),
                                        "删除群成员成功");
                                results.append("\n删除群成员成功\n");
                                showResult(results);
                                spinner_groups.setVisibility(View.GONE);
                                if (dialog != null) {
                                    dialog.dismiss();
                                }

                            }
                        });
                    }

                    @Override
                    public void onResultData(Object data) {
                        // 该方法不会调用
                    }

                    @Override
                    public void onFailure(final ErrorInfo errorInfo) {
                        // 删除群成员失败
                        runOnUiThread(new Runnable() {
                            public void run() {
                                ToastUtil.showToast(getApplicationContext(),
                                        "删除群成员失败：" + errorInfo.getCode() + ","
                                                + errorInfo.getReason());
                                results.append("\n删除群成员失败：\n"
                                        + errorInfo.getCode() + ","
                                        + errorInfo.getReason() + "\n");
                                showResult(results);
                            }
                        });
                    }
                });
    }

    public void publishGroupMsg(com.beidouapp.et.Message msg) {

        sdkContext.publishToGroup(groupId, 1, msg, new IActionListener() {

            @Override
            public void onSuccess() {
                // TODO Auto-generated method stub
                TestUtil.showTest("发布群消息成功");
                results.append("\n发布群消息成功");

                dialog.dismiss();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showResult(results);
                    }
                });
            }

            @Override
            public void onFailure(ErrorInfo arg0) {
                // TODO Auto-generated method stub
                TestUtil.showTest("发布群消息失败");
                results.append("\n发布群消息失败");
                dialog.dismiss();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showResult(results);
                    }
                });
            }
        });
    }

    /**
     * 注销群
     */
    public void dismissGroup() {
        sdkContext.dismissGroup(groupId, new IFriendsActionListener() {

            @Override
            public void onSuccess() {

                // 添加群成员成功
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(), "注销群成功");
                        // dialog.dismiss();
                        if (dialog != null) {
                            dialog.dismiss();
                        }
                        spinner_groups.setVisibility(View.GONE);
                        results.append("\n注销群成功\n");
                        showResult(results);
                    }
                });
            }

            @Override
            public void onResultData(Object data) {
                // 该方法不会调用
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 查询群消息失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "注销群失败：" + errorInfo.getCode() + ","
                                        + errorInfo.getReason());
                        results.append("\n注销群失败：\n" + errorInfo.getCode() + ","
                                + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });
            }
        });
    }

    /**
     * 发布主题消息
     *
     * @param content 内容
     * @param topic   主题
     */
    public void publish(String content, String topic) {
        com.beidouapp.et.Message message = new com.beidouapp.et.Message();
        boolean isHex = main_checkbox.isChecked();
        String str = "^[A-Fa-f0-9]+$", data = content.toString().trim();
        Pattern p = Pattern.compile(str);
        Matcher m = p.matcher(data);
        if (!m.matches() && isHex) {
            Toast.makeText(MainActivity.this, "请输入正确的16进制数据",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        byte[] payload;
        if (isHex) {
            payload = HexUtil.hexStrToByteArray(exTrim(content));
        } else {
            payload = content.getBytes();
        }
        message.setPayload(payload);
        sdkContext.publish(topic, 1, message, new IActionListener() {
            @Override
            public void onSuccess() {
                // 代表消息成功发送到服务器，不表示接收方已经收到消息。
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(), "发布主题成功");
                        results.append("\n发布主题成功\n");
                        showResult(results);
                    }
                });
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 发送失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "发布主题失败：" + errorInfo.getCode() + ","
                                        + errorInfo.getReason());
                        results.append("\n发布主题失败：\n" + errorInfo.getCode()
                                + "," + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });
            }
        });
    }

    /**
     * 订阅主题
     */
    public void subscribe() {
        String topic = et_subscribe_topic.getText().toString();
        if (topic.equals("")) {
            ToastUtil.showToast(getApplicationContext(), "请输入你要订阅的主题");
            return;
        }
        sdkContext.subscribe(topic, new IActionListener() {

            @Override
            public void onSuccess() {
                // 订阅主题成功
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(), "订阅主题成功");
                        results.append("\n订阅主题成功\n");
                        showResult(results);
                    }
                });
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 订阅主题失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "订阅主题失败：" + errorInfo.getCode() + ","
                                        + errorInfo.getReason());

                        results.append("\n订阅主题失败：\n" + errorInfo.getCode()
                                + "," + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });
            }
        });
    }

    /**
     * 取消订阅主题成功
     */
    public void unsubscribe() {
        String topic = et_subscribe_topic.getText().toString();
        if (topic.equals("")) {
            ToastUtil.showToast(getApplicationContext(), "请输入你要订阅的主题");
            return;
        }
        sdkContext.unsubscribe(topic, new IActionListener() {

            @Override
            public void onSuccess() {
                // 取消订阅主题成功
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil
                                .showToast(getApplicationContext(), "取消订阅主题成功");
                        results.append("\n取消订阅主题成功\n");
                        showResult(results);
                    }
                });
            }

            @Override
            public void onFailure(final ErrorInfo errorInfo) {
                // 取消订阅主题失败
                runOnUiThread(new Runnable() {
                    public void run() {
                        ToastUtil.showToast(getApplicationContext(),
                                "取消订阅主题失败：" + errorInfo.getCode() + ","
                                        + errorInfo.getReason());
                        results.append("\n取消订阅主题失败：\n" + errorInfo.getCode()
                                + "," + errorInfo.getReason() + "\n");
                        showResult(results);
                    }
                });
            }
        });
    }

    public void createDialog(String title, final boolean isAddFriend,
                             final String friendId) {
        new AlertDialog.Builder(MainActivity.this)
                .setTitle(title)
                .setPositiveButton("通知好友",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                if (isAddFriend) {
                                    addBuddyNotify(friendId);
                                } else {
                                    removeBuddyNotify(friendId);
                                }
                            }
                        })
                .setNegativeButton("不通知好友",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which) {
                                if (isAddFriend) {
                                    addBuddy(friendId);
                                } else {
                                    removeBuddy(friendId);
                                }
                            }
                        }).create().show();
    }

    /**
     * 展示发布主题对话框
     */
    public void showPublishTopicDialog() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_publish_topic, null);
        final EditText et_publish_topic = (EditText) view
                .findViewById(R.id.et_publish_topic);
        final EditText et_publish_content = (EditText) view
                .findViewById(R.id.et_publish_content);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("发布主题消息").setView(view);
        builder.setNegativeButton("取消",
                new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(final DialogInterface dialog, int which) {
                        canCloseDialog(dialog, true);
                        // dialog.dismiss();
                    }
                });
        builder.setPositiveButton("确定发布主题",
                new android.content.DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(final DialogInterface dialog, int which) {
                        String topic = et_publish_topic.getText().toString();
                        String content = et_publish_content.getText()
                                .toString();
                        if (topic.equals("")) {
                            ToastUtil.showToast(getApplicationContext(),
                                    "主题不能为空");
                            canCloseDialog(dialog, false);
                            return;
                        }
                        if (content.equals("")) {
                            ToastUtil.showToast(getApplicationContext(),
                                    "内容不能为空");
                            canCloseDialog(dialog, false);
                            return;
                        }
                        publish(content, topic);
                        canCloseDialog(dialog, true);
                    }
                });
        dialog = builder.show();
    }

    /**
     * 设置下拉框内容（群列表）
     *
     * @param arrGroups  群列表数组
     * @param listGroups 群列表集合
     */
    public void setSpinnerGroups(final String[] arrGroups,
                                 final List<GroupInfo> listGroups) {

        adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, arrGroups);
        // 设置下拉列表风格
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // 设置提示信息
        spinner_groups.setPrompt("选择你要查看的群");
        // 将适配器添加到spinner中去
        spinner_groups.setAdapter(adapter);
        spinner_groups.setVisibility(View.VISIBLE);
        spinner_groups.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View view,
                                       int position, long id) {
                isFist = true;
                if (position != 0) {
                    //  for (int i = 0; i < listGroups.size(); i++) {
//                        if (arrGroups[position].equals(listGroups.get(i)
//                                .getGroupname())) {
                    groupId = listGroups.get(position - 1).getTopic();
                    groupName = listGroups.get(position - 1).getGroupname();
                    getAllGroupMembers(groupId, listGroups);
                    //}
                    //  }
                }
                Log.d("test", "  onItemSelected");
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                Log.d("test", " onNothingSelected");
            }
        });
    }

    public void showGroupInfoDialog(final String[] member,
                                    final List<UserInfo> listGroupMember) {
        if (friendsForCreateGroup != null) {
            friendsForCreateGroup.clear();
        }
        isFist = false;
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_group_info, null);
        final Button btn_add_group_member = (Button) view
                .findViewById(R.id.btn_add_group_member);
        final Button btn_del_group_member = (Button) view
                .findViewById(R.id.btn_del_group_member);
        final Button btn_del_group = (Button) view
                .findViewById(R.id.btn_del_group);
        final Button publish_group = (Button) view
                .findViewById(R.id.btn_publish_group);
        final EditText data = (EditText) view.findViewById(R.id.et_group_msg);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("群成员列表：\n（群id:）:" + groupId).setView(view);
        builder.setMultiChoiceItems(member, null,
                new DialogInterface.OnMultiChoiceClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface,
                                        int which, boolean isChecked) {
                        ToastUtil.showToast(getApplicationContext(),
                                member[which] + ":" + isChecked);
                        if (isChecked) {
                            friendsForCreateGroup.add(member[which]);
                        } else {
                            if (member[which] != null) {
                                friendsForCreateGroup.remove(member[which]);
                            }
                        }
                    }
                });

        builder.setNegativeButton("关闭对话框",
                new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(final DialogInterface dialog1, int which) {
                        // canCloseDialog(dialog, true);
                        TestUtil.showTest("click关闭对话框");
                        if (dialog != null) {
                            dialog.dismiss();
                        }
                    }
                });
        dialog = builder.show();
        btn_add_group_member.setOnClickListener(new OnClickListener() {// 添加群成员

            @Override
            public void onClick(View v) {
                showFriendsForAdd();
            }
        });

        btn_del_group_member.setOnClickListener(new OnClickListener() {// 删除群成员

            @Override
            public void onClick(View v) {
                removeGroupMember();
                // canCloseDialog(dialog, true);

            }
        });
        publish_group.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                com.beidouapp.et.Message msg = new com.beidouapp.et.Message();
                String msgString = data.getText().toString().trim();
                if (msgString == null || msgString.equals("")) {
                    Toast.makeText(MainActivity.this, "输入消息内容",
                            Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    msg.setPayload(msgString.getBytes("UTF-8"));
                } catch (UnsupportedEncodingException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                publishGroupMsg(msg);
            }
        });

        btn_del_group.setOnClickListener(new OnClickListener() {// 注销群

            @Override
            public void onClick(View v) {
                dismissGroup();
            }
        });

        spinner_groups.setSelection(0);// 默认显示第0项
        adapter.notifyDataSetChanged();
        i++;
    }

    /**
     * 展示创建群窗口
     *
     * @param
     */
    public void showCreateDialog() {

        if (userInfoList == null) {
            ToastUtil.showToast(getApplicationContext(), "请先获取好友列表，再来创群");
            return;
        }
        int size = userInfoList.size();
        if (size <= 0) {
            ToastUtil.showToast(getApplicationContext(), "你还没有好友，请添加几个吧");
        }
        friendID = new String[size];
        for (int i = 0; i < size; i++) {
            friendID[i] = userInfoList.get(i).getUserid();
        }

        if (friendsForCreateGroup != null) {
            friendsForCreateGroup.clear();
        }

        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_create_group, null);
        final EditText et_group_name = (EditText) view
                .findViewById(R.id.et_group_name);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("选择好友并创建群").setView(view);
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                canCloseDialog(dialog, true);
                dialog.dismiss();
            }
        });
        builder.setMultiChoiceItems(friendID, null,
                new DialogInterface.OnMultiChoiceClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface,
                                        int which, boolean isChecked) {
                        if (isChecked) {
                            friendsForCreateGroup.add(friendID[which]);
                        } else {
                            if (friendID[which] != null) {
                                friendsForCreateGroup.remove(friendID[which]);
                            }
                        }

                    }
                });

        builder.setPositiveButton("确认创建",
                new android.content.DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(final DialogInterface dialog, int which) {
                        final String groupName = et_group_name.getText()
                                .toString();
                        if (groupName.equals("")) {
                            canCloseDialog(dialog, false);
                            ToastUtil.showToast(getApplicationContext(),
                                    "你没有输入群名字");
                            return;
                        }

                        createGroup(groupName, friendsForCreateGroup);
                        canCloseDialog(dialog, true);
                    }
                });
        dialog = builder.show();

    }

    /**
     * 展示添加好友列表对话框，在加群好友时
     */
    public void showFriendsForAdd() {

        if (userInfoList == null) {
            ToastUtil.showToast(getApplicationContext(), "请先获取好友列表，再来添加");
            return;
        }
        if (listGroupMember == null) {
            ToastUtil.showToast(getApplicationContext(), "群成员为null，请重新获取一次");
            return;
        }

        int size = userInfoList.size();
        if (size <= 0) {
            ToastUtil.showToast(getApplicationContext(), "你还没有好友，去添加几个再来加群好友吧");
            return;
        }
        final String[] friendStr = new String[size];
        for (int i = 0; i < size; i++) {
            friendStr[i] = userInfoList.get(i).getUserid();
        }
        if (friendsForCreateGroup != null) {
            friendsForCreateGroup.clear();
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("从好友列表中选择你要添加的人");
        builder.setMultiChoiceItems(friendStr, null,
                new DialogInterface.OnMultiChoiceClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface,
                                        int which, boolean isChecked) {
                        if (isChecked) {
                            if (listGroupMember != null) {// 剔除已在群列表的人
                                for (int i = 0; i < listGroupMember.size(); i++) {
                                    if (friendStr[which].equals(listGroupMember
                                            .get(i).getUserid())) {
                                        ToastUtil.showToast(
                                                getApplicationContext(),
                                                "该好友已在该群中,不需要重复添加");
                                        return;
                                    }
                                }
                            }
                            friendsForCreateGroup.add(friendStr[which]);
                        } else {
                            if (friendStr[which] != null) {
                                friendsForCreateGroup.remove(friendStr[which]);
                            }
                        }
                    }
                });

        builder.setPositiveButton("确认添加",
                new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(final DialogInterface dialog, int which) {
                        if (friendsForCreateGroup.size() <= 0) {
                            ToastUtil.showToast(getApplicationContext(),
                                    "你没有选择任何好友");
                            canCloseDialog(dialog, false);
                            return;
                        }
                        canCloseDialog(dialog, true);
                        addGroupMember();

                    }
                });

        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                canCloseDialog(dialog, true);
            }
        });
        dialog = builder.show();
    }

    // -------------------------------------------------------------------

    @Override
    public void onClick(View v) {
        final String friendId = et_friend_id.getText().toString();

        switch (v.getId()) {
            case R.id.btn_get_friends:// 获取好友列表
                getFriends();
                break;

            case R.id.btn_add_friend:// 添加好友
                createDialog("添加好友是否通知对方", true, friendId);
                break;

            case R.id.btn_delete_friend:// 删除好友
                createDialog("删除好友是否通知对方", false, friendId);
                break;

            case R.id.btn_send_msg:// 发送消息
                chatTo();
                break;

            case R.id.btn_register_offline_msg:// 获取离线消息
                requestOfflineMessage();
                break;

            case R.id.btn_disconnect_server:// 断开服务器连接
                mBinder.disconnect();
                break;

            case R.id.btn_get_groups:// 获取群列表
                getAllGroups();
                break;
            case R.id.btn_create_group:// 创建群

                showCreateDialog();
                // createGroup();
                break;

            case R.id.btn_state_unsubscribe:// 取消订阅用户的状态
                if (userInfoList == null) {
                    ToastUtil.showToast(getApplicationContext(), "请先获取好友列表");
                    return;
                }
                if (userInfoList != null && userInfoList.size() == 0) {
                    ToastUtil.showToast(getApplicationContext(), "你没有好友");
                    return;
                }
                for (int i = 0; i < userInfoList.size(); i++) {
                    if (!userInfoList.get(i).getUserid().equals(userId)) {
                        stateUnsubscribe(userInfoList.get(i).getUserid());
                    }
                }
                break;

            case R.id.btn_publish: // 发布主题
                showPublishTopicDialog();
                break;
            case R.id.btn_subscribe: // 订阅主题
                subscribe();
                break;
            case R.id.btn_unsubscribe:// 取消订阅主题
                unsubscribe();
                break;
            case R.id.btn_state_subscribe:// 订阅好友状态监听
                TestUtil.showTest("@@@@@@@@@@@@" + sdkContext.getSdkVersion());

                if (userInfoList == null) {
                    ToastUtil.showToast(getApplicationContext(), "请先获取好友列表");
                    return;
                }
                if (userInfoList != null && userInfoList.size() == 0) {
                    ToastUtil.showToast(getApplicationContext(), "你没有好友");
                    return;
                }
                for (int i = 0; i < userInfoList.size(); i++) {
                    if (!userInfoList.get(i).getUserid().equals(userId)) {
                        stateSubscribe(userInfoList.get(i).getUserid());
                    }
                }
                break;

            case R.id.btn_send_file:
                Intent intent = new Intent(MainActivity.this, FileActivity.class);
                startActivity(intent);
                break;
            default:
                break;
        }
    }

    /**
     * 关闭对话框
     *
     * @param dialogInterface
     * @param close
     */
    private void canCloseDialog(DialogInterface dialogInterface, boolean close) {
        try {
            Field field = dialogInterface.getClass().getSuperclass()
                    .getDeclaredField("mShowing");
            field.setAccessible(true);
            field.set(dialogInterface, close);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 展示操作日志
     */
    public void showResult(StringBuilder results) {
        tv_toast.setText(results.toString());
        handler.post(new Runnable() {

            @Override
            public void run() {
                scroll_view.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }

    /**
     * 注册广播
     */
    public void registBroadcase() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(EtConstant.GET_FRIEND_STATUS);
        filter.addAction(EtConstant.RECEIVE_MSG);
        filter.addAction(EtConstant.CONNECT_LOST_OTHER_REASON);
        filter.addAction(EtConstant.CONNECT_LOST_REPEAT_LOGIN);
        filter.addAction(EtConstant.DISCONNECT_SERVER_SUCCESS);
        filter.addAction(EtConstant.DISCONNECT_SERVER_FAILURE);
        filter.addAction(EtConstant.RECEIVE_FILE);
        rec = new MyBroadcaseReceiver();
        registerReceiver(rec, filter);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            mBinder.disconnect();
            if (mBinder != null) {
                mBinder.stopService();
            }
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            MainActivity.this.finish();
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unbindService(connection);
        if (mBinder != null) {
            mBinder.stopService();
        }
        if (rec != null) {
            unregisterReceiver(rec);
        }
        if (dialog != null) {
            dialog.dismiss();
        }
    }

    private class MyBroadcaseReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (EtConstant.GET_FRIEND_STATUS.equals(action)) {
                String status = "";// 0:离线, 1:在线
                if (intent.getStringExtra(EtConstant.FRIEND_STATUS_CODE)
                        .equals("1")) {
                    status = "在线";
                } else {
                    status = "离线";
                }
                results.append("\n"
                        + intent.getStringExtra(EtConstant.FRIEND_ID) + ":"
                        + status + "~~~"
                        + intent.getStringExtra(EtConstant.FRIEND_STATUS_CODE));
                showResult(results);
            } else if (EtConstant.RECEIVE_MSG.equals(action)) {
                results.append(
                        "\n\n接收到消息：\n" + "消息topic:"
                                + intent.getStringExtra("msgTopic")
                                + "发送的消息，消息内容：").append(
                        intent.getStringExtra("msgContent") + "\n");
                showResult(results);
            } else if (EtConstant.CONNECT_LOST_OTHER_REASON.equals(action)) {
                results.append("\n与服务器断开连接,3s后自动跳转到登录页面\n"
                        + intent.getStringExtra(EtConstant.ERROR) + "\n");
                showResult(results);

                handler.postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        Intent intentLogin = new Intent(MainActivity.this,
                                LoginActivity.class);
                        startActivity(intentLogin);
                        finish();
                    }
                }, 2000);

            } else if (EtConstant.DISCONNECT_SERVER_SUCCESS.equals(action)) {
                results.append("\n断开服务器成功,要想重新连接服务器，请自己重新登录吧 *_*\n");
                showResult(results);
            } else if (EtConstant.DISCONNECT_SERVER_FAILURE.equals(action)) {
                results.append("\n断开服务器失败\n"
                        + intent.getStringExtra(EtConstant.ERROR) + "\n");
                showResult(results);
            } else if (EtConstant.RECEIVE_FILE.equals(action)) {
                results.append(
                        "\n接收到文件：\n发送者："
                                + intent.getStringExtra(EtConstant.SEND_ID))
                        .append("\n文件信息："
                                + intent.getStringExtra(EtConstant.DOCUMENT_INFO)
                                + "\n");
                showResult(results);
            }

        }

    }
}
