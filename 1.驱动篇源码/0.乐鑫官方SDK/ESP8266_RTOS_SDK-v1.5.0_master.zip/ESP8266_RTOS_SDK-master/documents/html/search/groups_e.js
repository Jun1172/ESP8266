var searchData=
[
  ['wifi_20related_20apis',['WiFi Related APIs',['../group__WiFi__APIs.html',1,'']]],
  ['wps_20apis',['WPS APIs',['../group__WPS__APIs.html',1,'']]]
];
